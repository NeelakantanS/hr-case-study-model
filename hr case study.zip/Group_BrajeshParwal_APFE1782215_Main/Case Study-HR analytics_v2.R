#------------------------------------------- Problem Statement ----------------------------------------------------------#

# A large company named XYZ, employs, at any given point of time, around 4000 employees.
# However, every year, around 15% of its employees leave the company and need to be replaced with the talent pool available in the job market.
# The management believes that this level of attrition (employees leaving, either on their own or because they got fired) is bad for the company, because of the following reasons -
#   1.	The former employees' projects get delayed, which makes it difficult to meet timelines, resulting in a reputation loss among consumers and partners
#   2.	A sizeable department has to be maintained, for the purposes of recruiting new talent
#   3.	More often than not, the new employees have to be trained for the job and/or given time to acclimatise themselves to the company

# Hence, the management has contracted an HR analytics firm to understand what factors they should focus on, in order to curb attrition. 
# In other words, they want to know what changes they should make to their workplace, in order to get most of their employees to stay. 
# Also, they want to know which of these variables is most important and needs to be addressed right away.

# Goal of the case study
# You are required to model the probability of attrition using a logistic regression. 
# The results thus obtained will be used by the management to understand what changes they should make to their workplace, in order to get most of their employees to stay.
# Results Expected
# 1.	Write all your code in one well-commented R file; briefly, mention the insights and observations from the analysis
# 2.	Present the overall approach of the analysis in a presentation
#       a. Mention the problem statement and the analysis approach briefly
#       b. Explain the results in business terms
#       c. Include visualisations and summarise the most important results in the presentation


#------------------------------------------- Column definition -----------------------------------------------------------#

# Age	-	Age of the employee	
# Attrition	-	Whether the employee left in the previous year or not	
# BusinessTravel	-	How frequently the employees travelled for business purposes in the last year	
# Department	-	Department in company	
# DistanceFromHome	-	Distance from home in kms	
# Education	-	Education Level	- 'Below College', 'College',	'Bachelor', 'Master', 'Doctor'
# EducationField	-	Field of education	
# EmployeeCount	-	Employee count	
# EmployeeNumber	-	Employee number/id	
# Gender	-	Gender of employee	
# JobLevel	-	Job level at company on a scale of 1 to 5	
# JobRole	-	Name of job role in company	
# MaritalStatus	-	Marital status of the employee	
# MonthlyIncome	-	Monthly income in rupees per month	
# NumCompaniesWorked	-	Total number of companies the employee has worked for	
# Over18	-	Whether the employee is above 18 years of age or not	
# PercentSalaryHike	-	Percent salary hike for last year	
# RelationshipSatisfaction -	Relationship satisfaction level	- 'Low', 'Medium', 'High', 'Very High'
# StandardHours	-	Standard hours of work for the employee	
# StockOptionLevel	-	Stock option level of the employee	
# TotalWorkingYears	-	Total number of years the employee has worked so far	
# TrainingTimesLastYear	-	Number of times training was conducted for this employee last year	
# YearsAtCompany	-	Total number of years spent at the company by the employee	
# YearsSinceLastPromotion	-	Number of years since last promotion	
# YearsWithCurrManager	-	Number of years under current manager	

# Survey
# EnvironmentSatisfaction	-	Work Environment Satisfaction Level -	'Low','Medium','High', 'Very High'
# JobInvolvement -	Job Involvement Level	- 'Low', 'Medium', 'High', 'Very High'
# PerformanceRating	-	Performance rating for last year - 'Low', 'Good', 'Excellent', 'Outstanding'
# WorkLifeBalance	-	Work life balance level	- 'Bad', 'Good', 'Better', 'Best'
# JobSatisfaction	-	Job Satisfaction Level - 'Low', 'Medium', 'High', 'Very High'

#-----------------------------------------------# Load data set---------------------------------------------------------------------#


rm(list=ls())
setwd("C:/Users/rbose/Documents/Rajat/Study/Post Course/Assignment/Group Case Study 3 - HR Analytic LR/PA-I_Case_Study_HR_Analytics")

Emp_general_data <- read.csv("general_data.csv")
Emp_survey_data <- read.csv("employee_survey_data.csv")
Manager_survey_data <- read.csv("manager_survey_data.csv")
In_Time_data <- read.csv("in_time.csv", stringsAsFactors = FALSE)
Out_Time_Data <- read.csv("out_time.csv", stringsAsFactors = FALSE)


# the overall structure of HR Data (no. and type of variables)
str(Emp_general_data)     # 4410 obs. of  26 variables including the target variable
str(Emp_survey_data)      # 4410 obs. of  4 variables
str(Manager_survey_data)  # 4410 obs. of  3 variables
str(In_Time_data)         # 4410 obs. of  262 variables
str(Out_Time_Data)        # 4410 obs. of  262 variables

# install.packages("bda")
# install.packages("ROCR")
# install.packages("e1071")

library(stringr)
library(tidyr)
library(dplyr)
library(ggplot2)
library(e1071)
library(cowplot)    # for plot_grid
library(GGally)     # ggpair for correlation between numeric variables
library(car)      # for stepAIC function
library(bda)        # for binning function
library(caret)      # for confusionMatrix function
library(ROCR)       # for prediction
library(pROC)       # roc function
library(MASS)       # for stepAIC function 





#----------------------------------------- Data pre-processing ----------------------------------------------------#

# Data Understanding

# First column in data set "In_Time_data" and "Out_Time_Data"  do not have any header. On eyeballing the values it seems to be Employee ID
# Hence name the first column as EmployeeID
colnames(In_Time_data)[1]  <- c("EmployeeID")
colnames(Out_Time_Data)[1] <- c("EmployeeID")

# total missing value count
sum(is.na(In_Time_data))    # 109080
sum(is.na(Out_Time_Data))   # 109080

# Check 
# 1 the employee count and 
# 2 if all employee exists in all the datasets

length(unique(tolower(Emp_general_data$EmployeeID)))    # 4410, confirming EmployeeID is key 
length(unique(tolower(Emp_survey_data$EmployeeID)))     # 4410, confirming EmployeeID is key
length(unique(tolower(In_Time_data$EmployeeID)))        # 4410, confirming EmployeeID is key
length(unique(tolower(Out_Time_Data$EmployeeID)))       # 4410, confirming EmployeeID is key
length(unique(tolower(Manager_survey_data$EmployeeID))) # 4410, confirming EmployeeID is key


# Identical EmployeeID across these datasets
setdiff(In_Time_data$EmployeeID, Out_Time_Data$EmployeeID)       
setdiff(Emp_survey_data$EmployeeID, In_Time_data$EmployeeID)     
setdiff(Emp_survey_data$EmployeeID, Out_Time_Data$EmployeeID)    
setdiff(Emp_general_data$EmployeeID, In_Time_data$EmployeeID)    
setdiff(Emp_general_data$EmployeeID, Out_Time_Data$EmployeeID)   
setdiff(Emp_survey_data$EmployeeID, Emp_general_data$EmployeeID) 
setdiff(Manager_survey_data$EmployeeID, Emp_general_data$EmployeeID) 
setdiff(Manager_survey_data$EmployeeID, Emp_survey_data$EmployeeID)



# --------------------------------------- Data Preparation ----------------------------------------------------------------- #

# convert wide dataset "In_Time_data" and "Out_Time_Data" to long dataset
# gather the data together. We need to have a key value pair. The key is the date and the value is datetime

InTime_data_long <- gather(In_Time_data, Date, InTime, 2:261)
OutTime_data_long <- gather(Out_Time_Data, Date, OutTime, 2:261)

# create separate date and time column (date time value sample: 2015-12-31 10:12:44)
InTime_data_long$Date <- format(strptime(InTime_data_long$InTime,"%Y-%m-%d %H:%M:%S",tz=""),"%Y-%m-%d")
InTime_data_long$InTime <- format(strptime(InTime_data_long$InTime,"%Y-%m-%d %H:%M:%S",tz=""),"%H:%M:%S")

OutTime_data_long$Date <- format(strptime(OutTime_data_long$OutTime,"%Y-%m-%d %H:%M:%S",tz=""),"%Y-%m-%d")
OutTime_data_long$OutTime <- format(strptime(OutTime_data_long$OutTime,"%Y-%m-%d %H:%M:%S",tz=""),"%H:%M:%S")

# retain EmployeeID and parsed date time column (Date, InTime)
InTime_data <- InTime_data_long[,c(1,3,4)]

OutTime_data <- OutTime_data_long[,c(1,3,4)]

head(na.omit(InTime_data))
head(na.omit(OutTime_data))


# For InTime dataset:- Check for missing value count by column
sapply(InTime_data, function(x) sum(is.na(x)))    # there are missing values 

# Count unique values by the columns
as.data.frame(rapply(InTime_data,function(x)length(unique(x))))  # EmployeeID - 4410, Date - 249


# For OutTime dataset:- Check for missing values by column
sapply(OutTime_data, function(x) sum(is.na(x)))   # there are missing values

# Count unique values by the columns
as.data.frame(rapply(OutTime_data,function(x)length(unique(x)))) # EmployeeID - 4410, Date - 249

# Observation: Employee count and date count in both the dataset "InTime_data" and  "OutTime_data" matches


# merge the employee in and out time 
InTime_OutTime_data <- merge(InTime_data, OutTime_data, by= c("EmployeeID","Date"), all = F)
str(InTime_OutTime_data)           # 3857860 obs. of  4 variables

# Count unique values by the columns in merged dataset
as.data.frame(rapply(InTime_OutTime_data,function(x)length(unique(x))))   # Count observation: EmployeeID :- 4410, Date :- 249

# converting date value from character to date datatype
InTime_OutTime_data$Date <- as.Date(InTime_OutTime_data$Date)


#--- Calculating time difference in hours only ------------
time.diff_hr <- as.numeric(difftime(strptime(paste(InTime_OutTime_data[,2],InTime_OutTime_data[,4]),"%Y-%m-%d %H:%M:%S"),
                                    strptime(paste(InTime_OutTime_data[,2],InTime_OutTime_data[,3]),"%Y-%m-%d %H:%M:%S")),units = c("hours"))    # units = c("auto", "secs", "mins", "hours", "days", "weeks")


# Appending the time difference column to employee punch time dataset
InTime_OutTime_data <- cbind(InTime_OutTime_data[,c(1:4)],time.diff_hr )
head(InTime_OutTime_data)

# Merge dataset "Emp_survey_data" and "Manager_survey_data"
Survey_data <- merge(Emp_survey_data, Manager_survey_data, by = "EmployeeID", all=F )


#------ Compare the employee count in emp and manager survey dataset w.r.t merged data set

# Count unique values by the columns in merged "Emp_survey_data" dataset
as.data.frame(rapply(Emp_survey_data,function(x)length(unique(x)))) # Count observation: EmployeeID :- 4410

# Count unique values by the columns in "merged"Manager_survey_data" dataset
as.data.frame(rapply(Manager_survey_data,function(x)length(unique(x))))  # Count observation: EmployeeID :- 4410, JobInvolvement = 4, PerformanceRating = 2


# Count unique values by the columns in merged dataset
as.data.frame(rapply(Survey_data,function(x)length(unique(x))))   # Count observation: EmployeeID :- 4410, JobInvolvement = 4, PerformanceRating = 2

# Observation: Count matches

# Merge dataset "Survey_data" and "Emp_general_data"
Emp_attrition_data <- merge(Survey_data, Emp_general_data, by = "EmployeeID", all=F )
str(Emp_attrition_data)   # 4410 obs. of  29 variables


# Check duplicate rows in merged dataset
x<-Emp_attrition_data[duplicated(Emp_attrition_data), ]
dim(x) # No duplicate rows

# Check duplicate value in column EmployeeId
any(duplicated(Emp_attrition_data$EmployeeID)) # no duplicate value

# Check for total NA in merged dataset
na_merged_dt <- table(is.na(Emp_attrition_data))
na_merged_dt   # 111 NA values

# Rename columns from survey dataset for easy identifiction of column source
colnames(Emp_attrition_data)[2] <- c("Survey_EnvironmentSatisfaction")
colnames(Emp_attrition_data)[3] <- c("Survey_JobSatisfaction")
colnames(Emp_attrition_data)[4] <- c("Survey_WorkLifeBalance")
colnames(Emp_attrition_data)[5] <- c("Survey_JobInvolvement")
colnames(Emp_attrition_data)[6] <- c("Survey_PerformanceRating")


# Assigning definition to values of categorical variables - 
# Education, EnvironmentSatisfaction,JobInvolvement, JobSatisfaction,PerformanceRating, WorkLifeBalance, JobLevel
# And converting to factor

Emp_attrition_data$Education <- factor(Emp_attrition_data$Education,
                                       levels = c(1,2,3,4,5),
                                       labels = c("Below_College", "College", "Bachelor","Master","Doctor"))


Emp_attrition_data$Survey_EnvironmentSatisfaction <- factor(Emp_attrition_data$Survey_EnvironmentSatisfaction,
                                                     levels = c(1,2,3,4),
                                                     labels = c("Low", "Medium", "High","Very_High"))

Emp_attrition_data$Survey_JobInvolvement <- factor(Emp_attrition_data$Survey_JobInvolvement,
                                            levels = c(1,2,3,4),
                                            labels = c("Low", "Medium", "High","Very_High"))

Emp_attrition_data$Survey_JobSatisfaction <- factor(Emp_attrition_data$Survey_JobSatisfaction,
                                             levels = c(1,2,3,4),
                                             labels = c("Low", "Medium", "High","Very_High"))

Emp_attrition_data$Survey_PerformanceRating <- factor(Emp_attrition_data$Survey_PerformanceRating,
                                               levels = c(1,2,3,4),
                                               labels = c("Low","Good","Excellent","Outstanding"))

Emp_attrition_data$Survey_WorkLifeBalance <- factor(Emp_attrition_data$Survey_WorkLifeBalance,
                                             levels = c(1,2,3,4),
                                             labels = c("Bad", "Good", "Better","Best"))

Emp_attrition_data$JobLevel <- factor(Emp_attrition_data$JobLevel)

Emp_attrition_data$Attrition <- factor(Emp_attrition_data$Attrition,
                                       levels = c("Yes", "No"),
                                       labels = c(1,0))
str(Emp_attrition_data)
# Convert factor to integer
Emp_attrition_data$Attrition <- strtoi(Emp_attrition_data$Attrition)


# Exclude columns from merged data set which have single unique value 

# Observation: Columns which do not seem to add value to the model are "Over18", "EmployeeCount", "StandardHours" 
unique(Emp_attrition_data$Over18) # only one unique value = Y
unique(Emp_attrition_data$EmployeeCount) # only one unique value = 1
unique(Emp_attrition_data$StandardHours) # only one unique value = 8



# identify column number of the variable
grep("Over18", colnames(Emp_attrition_data))          # 21
grep("EmployeeCount", colnames(Emp_attrition_data))   # 14
grep("StandardHours", colnames(Emp_attrition_data))   # 23



# Excluding the columns "Over18","EmployeeCount" & "StandardHours" from the dataset as it doesn't carry any value to the model 
Emp_attrition_data = Emp_attrition_data[,c(-21,-14,-23)]
dim(Emp_attrition_data)  # 4410   26


# Create dataset for factor variable 
factor_df <- Emp_attrition_data[,which(sapply(Emp_attrition_data, is.factor))]
str(factor_df)


# Create dataset for numeric/integer variable 
continuous_df <- Emp_attrition_data[,which(sapply(Emp_attrition_data, is.numeric))]
str(continuous_df)


outlier_quant <- sapply(continuous_df, function(x) quantile(na.omit(x),seq(0,1,.01)))
summary(outlier_quant)    # Column DistanceFromHome, MonthlyIncome and YearsAtCompany have outliers


# ----------------------------------------- Data Preparation ends --------------------------------------------------------- #


# ----------------------------------------- Missing value analysis & treatment -------------------------------------------- #

# --- Analysis

# Analyze variables with missing values
missing_value_pct <- Emp_attrition_data %>%
  summarise_all(funs(sum(is.na(.))/n()))

# Long format
missing_value_pct <- gather(missing_value_pct,key='feature',value = 'missing_proportion')

# For display: Ordering by missing proportion
missing_value_pct[order(missing_value_pct$missing_proportion),]

# plot the missing values as percentage
missing_value_pct %>%
  ggplot(aes(x=reorder(feature,-missing_proportion),y=missing_proportion)) +
  geom_bar(stat = 'identity',fill='red')+
  labs(title="Plot on missing values",x="Column name",y="missing_proportion") +
  theme(axis.text.x=element_text(angle=90, hjust=1))


# Observation: Five columns TotalWorkingYears, NumCompaniesWorked, Survey_JobSatisfaction, Survey_EnvironmentSatisfaction, Survey_WorkLifeBalance
# have missing values which is less then 1% of total observations


# Create two separate dataset :- one for missing values and other all values populated

# list rows of data that have missing values
EmpAttrition_rows_with_missing_values <- Emp_attrition_data[!complete.cases(Emp_attrition_data),]

# list rows of data that do not have missing values
EmpAttrition_rows_without_missing_values <- Emp_attrition_data[complete.cases(Emp_attrition_data),]

# Lets check average attrition after excluding rows with missing values 
summary(Emp_attrition_data$Attrition)                       # Observation: Average attrition of (711/4410) 16% - means that 16% of our employees has left in the last year
summary(EmpAttrition_rows_without_missing_values$Attrition) # Observation: Average attrition remains same at (695/4300) 16% after excluding the rows with missing values

# Observation: No difference in Average attrition


# ------ Treatment of missing values

# --- 1 Survey_EnvironmentSatisfaction, Survey_JobSatisfaction and Survey_WorkLifeBalance

# Since column Survey_EnvironmentSatisfaction, Survey_JobSatisfaction and Survey_WorkLifeBalance are factors, 
# we need to defactor the column first and then add level to it

# Assign "Not Available" to missing column value 

# Step 1:-  Get levels and add "Not Available"
level <- levels(Emp_attrition_data[which(is.na(Emp_attrition_data$Survey_EnvironmentSatisfaction)),]$Survey_EnvironmentSatisfaction)
level_1 <- levels(Emp_attrition_data[which(is.na(Emp_attrition_data$Survey_JobSatisfaction)),]$Survey_JobSatisfaction)
level_2 <- levels(Emp_attrition_data[which(is.na(Emp_attrition_data$Survey_WorkLifeBalance)),]$Survey_WorkLifeBalance)
level[length(level) + 1] <- "Not Available"
level_1[length(level_1) + 1] <- "Not Available"
level_2[length(level_2) + 1] <- "Not Available"

# Step 2:- refactor Survey_EnvironmentSatisfaction to include "Not Available" as a factor level
# and replace missing value with "Not Available"
Emp_attrition_data$Survey_EnvironmentSatisfaction <- factor(Emp_attrition_data$Survey_EnvironmentSatisfaction, levels = level)
Emp_attrition_data$Survey_EnvironmentSatisfaction[is.na(Emp_attrition_data$Survey_EnvironmentSatisfaction)] <- "Not Available"

Emp_attrition_data$Survey_JobSatisfaction <- factor(Emp_attrition_data$Survey_JobSatisfaction, levels = level_1)
Emp_attrition_data$Survey_JobSatisfaction[is.na(Emp_attrition_data$Survey_JobSatisfaction)] <- "Not Available"

Emp_attrition_data$Survey_WorkLifeBalance <- factor(Emp_attrition_data$Survey_WorkLifeBalance, levels = level_2)
Emp_attrition_data$Survey_WorkLifeBalance[is.na(Emp_attrition_data$Survey_WorkLifeBalance)] <- "Not Available"

str(Emp_attrition_data)   # 4410 obs. of  26 variables


# NA should be replaced with Not Available anc count should match
summary(Emp_attrition_data$Survey_EnvironmentSatisfaction) # Not Available = 25
summary(EmpAttrition_rows_with_missing_values$Survey_EnvironmentSatisfaction) # NA's = 25
summary(Emp_attrition_data$Survey_JobSatisfaction) # 20
summary(Emp_attrition_data$Survey_WorkLifeBalance) # 38


# --- 2 NumCompaniesWorked

# For all the observations with NumCompaniesWorked = NA, we observe that TotalWorkingYears >= YearsAtCompany
# Assumption: Column NumCompaniesWorked means company count which employees have worked in past
# Scenario 1: Where TotalWorkingYears is equal to YearsAtCompany, it implies that employee have worked with no other company in past
# Hence NumCompaniesWorked can be assigned value equal to 0
# Scenario 2: Where TotalWorkingYears is more then YearsAtCompany, it implies employee have had worked in atleast one company in past
# Hence NumCompaniesWorked can be assigned value equal to 1


if (Emp_attrition_data$TotalWorkingYears==Emp_attrition_data$YearsAtCompany) {Emp_attrition_data[which(is.na(Emp_attrition_data$NumCompaniesWorked)),]$NumCompaniesWorked<- 0
} else if (Emp_attrition_data$TotalWorkingYears > Emp_attrition_data$YearsAtCompany) { Emp_attrition_data[which(is.na(Emp_attrition_data$NumCompaniesWorked)),]$NumCompaniesWorked<-1
} # Ignore the warning

# Check the summary pre amd post assigning the values to column NumCompaniesWorked = NA
summary(Emp_attrition_data$NumCompaniesWorked)
summary(EmpAttrition_rows_with_missing_values$NumCompaniesWorked)



# --- 3 TotalWorkingYears

# For all the observations with TotalWorkingYears = NA, we observe that NumCompaniesWorked >= 0
# Scenario 1: Where NumCompaniesWorked is equal to 0, that is employee has not worked with any company in past, TotalWorkingYears = YearsAtCompany
# Scenario 2: Where NumCompaniesWorked is greater then 0, that is employee has worked with atleast one company in past, TotalWorkingYears = YearsAtCompany + 1

if (Emp_attrition_data$NumCompaniesWorked == 0) {Emp_attrition_data[which(is.na(Emp_attrition_data$TotalWorkingYears)),]$TotalWorkingYears <- Emp_attrition_data[which(is.na(Emp_attrition_data$TotalWorkingYears)),]$YearsAtCompany
} else if (Emp_attrition_data$NumCompaniesWorked > 0) {Emp_attrition_data[which(is.na(Emp_attrition_data$TotalWorkingYears)),]$TotalWorkingYears <- Emp_attrition_data[which(is.na(Emp_attrition_data$TotalWorkingYears)),]$YearsAtCompany+1
} # Ignore the warning

# Check the summary pre amd post assigning the values to column TotalWorkingYears = NA
summary(Emp_attrition_data$TotalWorkingYears)
summary(EmpAttrition_rows_with_missing_values$TotalWorkingYears)



# ----------------------------------------- Adding new feature -------------------------------------------------------------- #

# Average time spent by employee in office
# Emmployee compensation relative to other employees in same role

# 1 
# Average office duration of an employee 
Avg <- InTime_OutTime_data %>% 
  group_by(EmployeeID) %>%
  summarise(Avg_emp_time_at_office = mean(time.diff_hr, na.rm = T))

Emp_attrition_data <- merge(Emp_attrition_data, Avg, by = "EmployeeID",  all=F )


# 2 
# Since Salary is proportional to various factor like work experience, education, job level etc 
# lets create a variable which will look at monthly income relative to median salary of employees at various job level

# Median salary of employee per job role 
Median_Sal <- Emp_attrition_data %>% 
  group_by(JobRole) %>%
  summarise(Median_Sal_Role = median(MonthlyIncome, na.rm = T))

Emp_attrition_data <- merge(Emp_attrition_data,Median_Sal, by="JobRole" , all=F)

# Add new derived variable to existing merged data set
Emp_attrition_data <- mutate(Emp_attrition_data, Sal_diff= MonthlyIncome - Median_Sal_Role, Emp_Comp_ratio = MonthlyIncome/Median_Sal_Role )
str(Emp_attrition_data)



# ---- Creating bucket

# Since PercentSalaryHike, NumCompaniesWorked, YearsAtCompany, Monthly Income are highly skewed, 
# we can analyze them in bucket or log transform the variable

Emp_attrition_data$PercentSalaryHike_bucket <- as.factor(ifelse(Emp_attrition_data$PercentSalaryHike<=13,"11-13",
                                                                ifelse(Emp_attrition_data$PercentSalaryHike<=15,"13.1-15",
                                                                       ifelse(Emp_attrition_data$PercentSalaryHike<=17,"15.1-17",
                                                                              ifelse(Emp_attrition_data$PercentSalaryHike<=19,"17.1-19",
                                                                                     ifelse(Emp_attrition_data$PercentSalaryHike<=21,"19.1-21",
                                                                                            ifelse(Emp_attrition_data$PercentSalaryHike<=23,"19.1-23","23.1-25")))))))


Emp_attrition_data$YearsAtCompany_bucket <- as.factor(ifelse(Emp_attrition_data$YearsAtCompany<=4,"0-4",
                                                             ifelse(Emp_attrition_data$YearsAtCompany<=8,"4.1-8",
                                                                    ifelse(Emp_attrition_data$YearsAtCompany<=12,"8.1-12",
                                                                           ifelse(Emp_attrition_data$YearsAtCompany<=16,"12.1-16",
                                                                                  ifelse(Emp_attrition_data$YearsAtCompany<=20,"16.1-20",
                                                                                         ifelse(Emp_attrition_data$YearsAtCompany<=24,"20.1-24",
                                                                                                ifelse(Emp_attrition_data$YearsAtCompany<=28,"24.1-28",
                                                                                                       ifelse(Emp_attrition_data$YearsAtCompany<=32,"28.1-32",
                                                                                                              ifelse(Emp_attrition_data$YearsAtCompany<=36,"32.1-36", "36.1-40"))))))))))


Emp_attrition_data$DistanceFromHome_bucket <- as.factor(ifelse(Emp_attrition_data$DistanceFromHome<=3,"0-3",
                                                               ifelse(Emp_attrition_data$DistanceFromHome<=6,"3.1-6",
                                                                      ifelse(Emp_attrition_data$DistanceFromHome<=9,"6.1-9",
                                                                             ifelse(Emp_attrition_data$DistanceFromHome<=12,"9.1-12",
                                                                                    ifelse(Emp_attrition_data$DistanceFromHome<=15,"12.1-15",
                                                                                           ifelse(Emp_attrition_data$DistanceFromHome<=18,"15.1-18",
                                                                                                  ifelse(Emp_attrition_data$DistanceFromHome<=21,"18.1-21",
                                                                                                         ifelse(Emp_attrition_data$DistanceFromHome<=24,"21.1-24",
                                                                                                                ifelse(Emp_attrition_data$DistanceFromHome<=27,"24.1-27", "27.1-29"))))))))))

Emp_attrition_data$NumCompaniesWorked_bucket <-  as.factor(ifelse(Emp_attrition_data$NumCompaniesWorked<=1,"0-1",
                                                                  ifelse(Emp_attrition_data$NumCompaniesWorked<=2,"1.1-2",
                                                                         ifelse(Emp_attrition_data$NumCompaniesWorked<=3,"2.1-3",
                                                                                ifelse(Emp_attrition_data$NumCompaniesWorked<=3,"3.1-4",
                                                                                       ifelse(Emp_attrition_data$NumCompaniesWorked<=4,"4.1-5",
                                                                                              ifelse(Emp_attrition_data$NumCompaniesWorked<=5,"5.1-6",
                                                                                                     ifelse(Emp_attrition_data$NumCompaniesWorked<=6,"5.1-6",
                                                                                                            ifelse(Emp_attrition_data$NumCompaniesWorked<=7,"6.1-7",
                                                                                                                   ifelse(Emp_attrition_data$NumCompaniesWorked<=8,"7.1-8", "8.1-9"))))))))))



Emp_attrition_data$YearsSinceLastPromotion_bucket <- as.factor(ifelse(Emp_attrition_data$YearsSinceLastPromotion<=2,"0-2",
                                                                      ifelse(Emp_attrition_data$YearsSinceLastPromotion<=4,"2.1-4",
                                                                             ifelse(Emp_attrition_data$YearsSinceLastPromotion<=6,"4.1-6",
                                                                                    ifelse(Emp_attrition_data$YearsSinceLastPromotion<=8,"6.1-8",
                                                                                           ifelse(Emp_attrition_data$YearsSinceLastPromotion<=10,"8.1-10",
                                                                                                  ifelse(Emp_attrition_data$YearsSinceLastPromotion<=12,"10.1-12",
                                                                                                         ifelse(Emp_attrition_data$YearsSinceLastPromotion<=14,"12.1-14","14.1-16"))))))))


# log transform MonthlyIncome 
Emp_attrition_data$MonthlyIncome_transformed <- log(Emp_attrition_data$MonthlyIncome) 


# ------------------------------------------ End of feature creation ---------------------------------------------------- #




# ----------------------------------- Exploratory Data Analysis ------------------------------------------

# ------ analyze the distribution of each independent continuous variable:

# Univariate plot

continuous_df_1 <- continuous_df[,-3]  # excluding predictor variable (Attrition) from plot

# 1
par(mfrow = c(4,2))
par(mar = rep(2, 4))
for( i in 2:6){
  hist(continuous_df_1[,i], main = colnames(continuous_df_1)[i],xlab = colnames(continuous_df_1)[i], col = 'yellow')
}

# 2
par(mfrow = c(4,2))
par(mar = rep(2, 4))
for( i in 7:12){
  hist(continuous_df_1[,i], main = colnames(continuous_df_1)[i],xlab = colnames(continuous_df_1)[i], col = 'yellow')
}

summary(continuous_df_1)

# Observation: From the plot it is evident -  PercentSalaryHike, NumCompaniesWorked, YearsAtCompany, TotalWorkingYear, YearsSinceLastPromotion are highly skewed
# So we can analyze them in bucket and log transform Monthly Income

# To create bucket we need optimal bin width. Basis the bin width we will bucket the variables and label them 

bin_width <- function(x){
  bin_cnt <- diff(range(x)) / (2 * IQR(x) / length(x)^(1/3))     # Freedman-Diaconis rule
  bin_widt <- 2 * IQR(x) / length(x)^(1/3)
  x <- c(bin_count = bin_cnt, bin_width = bin_widt)
  return(x)
}

bin_width(Emp_attrition_data$MonthlyIncome)  # bin width = 6700, bin count = 28
bin_width(log(Emp_attrition_data$MonthlyIncome))  # bin width = 0.2, bin count = 23
bin_width(Emp_attrition_data$PercentSalaryHike) # bin width = 0.7, bin count = 19
bin_width(Emp_attrition_data$NumCompaniesWorked) # bin width = 0.4, bin count = 25
bin_width(Emp_attrition_data$YearsAtCompany) # bin width = 0.7, bin count = 55
bin_width(Emp_attrition_data$YearsSinceLastPromotion) # bin width = 0.4, bin count = 41
bin_width(Emp_attrition_data$DistanceFromHome) # bin width = 1.5, bin count = 19
bin_width(Emp_attrition_data$TotalWorkingYear) # bin width = 1.1, bin count = 36




# Plot for continuous independent variables distribution

# Transformed MonthlyIncome
MonthlyIncome_bin_1 <- binning(x=log(Emp_attrition_data$MonthlyIncome), bw = 0.2)
plot(MonthlyIncome_bin_1)

# PercentSalaryHike
PercentSalaryHike_bin <- binning(x=Emp_attrition_data$PercentSalaryHike, bw = 0.7)
plot(PercentSalaryHike_bin)

# NumCompaniesWorked
NumCompaniesWorked_bin <- binning(x=Emp_attrition_data$NumCompaniesWorked, bw = 0.4)
plot(NumCompaniesWorked_bin)

# TotalWorkingYear
TotalWorkingYear_bin <- binning(x=log(Emp_attrition_data$TotalWorkingYear), bw = 0.6)
plot(TotalWorkingYear_bin)

# YearsAtCompany
YearsAtCompany_bin <- binning(x=Emp_attrition_data$YearsAtCompany, bw = 0.7)
plot(YearsAtCompany_bin)

# YearsSinceLastPromotion
YearsSinceLastPromotion_bin <- binning(x=Emp_attrition_data$YearsSinceLastPromotion, bw = 0.4)
plot(YearsSinceLastPromotion_bin)


# --- To get more clarity on the distribution of continuous independent variables like Age, monthly income etc, we can analyzing it w.r.t. dependent variable 

# ------ Analyze Age of the employees
ggplot(Emp_attrition_data, aes(x = Age, fill= factor(Attrition))) + 
  geom_histogram( col="red",  alpha = .3, binwidth = 1.6) + # geom_density()+
  labs(title="Employee Age Distribution", x="Age", y="Count")

boxplot(Age~Attrition, xlab= "Attrition", ylab="Age",  col="light blue",data = Emp_attrition_data)

emp_quit_dataset <- Emp_attrition_data[which(Emp_attrition_data$Attrition==1),]
summary(emp_quit_dataset$Age)  # 32

# Observation: from the plot we observe that young employees mostly between 25 - 35 and the median age of 32 had quit in last one year


# ------ Analyze Monthly income of employee
ggplot(Emp_attrition_data, aes(x = MonthlyIncome, fill= factor(Attrition))) +
  geom_histogram( col="black",  alpha = .3, binwidth = 6700) + # geom_density()+
  labs(title="Employee Monthly Income Distribution", x="Monthly Income", y="Count")

boxplot(log(MonthlyIncome)~Attrition, xlab= "Attrition", ylab="Transformed MonthlyIncome",  col="light blue",data = Emp_attrition_data)

summary(emp_quit_dataset$MonthlyIncome) 

# Observation: From above plot, we observe from that most employees, who had quit, were getting salary less then median salary of 50K


# ------ Apply log transformation to Monthly income and plot histogram again
ggplot(Emp_attrition_data, aes(x = log(MonthlyIncome), fill= factor(Attrition))) +
  geom_histogram( col="black",  alpha = .3, binwidth = 0.2) + #geom_density()+
  labs(title="Employee Monthly Income Distribution", x="Monthly Income", y="Count")

# Observation: Approx normal distribution


# ------ Box plot by job role and Monthly income of employees
ggplot(Emp_attrition_data, aes(x = JobRole, y = MonthlyIncome)) +
  geom_boxplot(outlier.colour="black", outlier.shape=1,
               outlier.size=2, notch=FALSE)+
  labs(title="Employee Monthly Income Distribution by Job Role", x="Job Role", y="Monthly Income")+
  theme(axis.text.x=element_text(angle=90, hjust=1))


# ------ Box plot by job role and transformed monthly income of employees who have either left or are active
ggplot(Emp_attrition_data, aes(x = JobRole, y=log(MonthlyIncome),fill= factor(Attrition))) +
  geom_boxplot()+
  labs(title="Employee Data - Monthly Income", x="Job Role", y="Transformed Monthly Income") +
  theme(axis.text.x=element_text(angle=90, hjust=1))

# Observation: The salary of employees in 1st Quartile for some job role is approx same, 
# example: Healthcare Representative, Lab Technician, Research Scientist, Sales representative has apporx same salary
# Median salary of lab technician and manufacturing director is approx same
# from box plot it seems salary of employee with different roles overlap


# ---------- For categorical independent variables, we can analyze the frequency of each category w.r.t. the dependent variable

# --- Gender Analysis

Gender_Cnt <- Emp_attrition_data %>% group_by(Gender) %>% summarise(tot_cnt=n())
Emp_Churn_by_Gender <- Emp_attrition_data %>% group_by(Attrition,Gender) %>% summarise(cnt=n() )
Merge_Gender_Churn <- merge(Emp_Churn_by_Gender,Gender_Cnt,by="Gender",all=F)
fraction_Cnt <- Merge_Gender_Churn %>% group_by(Gender,Attrition) %>% summarise(fraction=round(cnt/tot_cnt,2))
fraction_attrition_by_gender <- merge( Merge_Gender_Churn, fraction_Cnt, by=c("Gender","Attrition"),all=F)
fraction_attrition_by_gender

xtabs(~Attrition + Gender, data = Emp_attrition_data)

ggplot(Emp_attrition_data, aes(x = Gender,  fill= Attrition)) + 
  geom_bar(  alpha = .7, width=0.3) + 
  ggtitle("Attrition by Gender") + 
  labs (x = "Gender", y = "Proportion Leaving" )


# Observation: Attrition rate of male members are higher when compared to female members

# --- Employement duration analysis

xtabs(~Attrition + YearsAtCompany_bucket, data = Emp_attrition_data)

# Observation: employees who had joined company recent to upto 4 years are the one who had quit in last one year

# --- Emp training analysis

xtabs(~Attrition + TrainingTimesLastYear, data = Emp_attrition_data)

# Observation: employees who were trained twice or thrice we the ones who had quit in last one year


#------ Department (Business Area) Analysis

Emp_Churn_by_dept <- Emp_attrition_data %>% group_by(Attrition,Department) %>% summarise(cnt=n() )

ggplot(Emp_attrition_data, aes(x = factor(Department), fill = Attrition)) +
  geom_bar( alpha = .7, width = 0.4) +   # fill = "#E69F00"
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = 2.5) +
  ggtitle("Attrition by Department") + 
  labs (x = "Department", y = "Proportion Leaving" )

xtabs(~Attrition + Department, data = Emp_attrition_data)

# Observation: From above graph, among the three departments, attrition rate is highest from research & development department


#------ Department (Business Area) and gender Analysis

Emp_Churn_by_dept_gender <- Emp_attrition_data %>% group_by(Department,Gender,Attrition) %>% summarise(cnt=n() )

ggplot(data=Emp_Churn_by_dept_gender, 
       aes(x=Department, y=cnt, 
           group=Gender,
           shape=Gender,
           color=Gender)) + 
  geom_line() + 
  geom_point() +
  ggtitle("Attirtion by Department and Gender") +
  # scale_x_discrete("Year") +
  # scale_y_continuous("Proportion Tasty") + 
  facet_grid(.~Attrition )


# Observation: From above graph, attrition of male employees compared to female employee is more from the research and developement department followed by sales department,
# while its almost equal in case of human resource

 
# ------ Boxplots of numeric variables relative to employee attrition
# 
# First set
plot_grid(
  ggplot(Emp_attrition_data, aes(x=factor(Attrition),y=Age, fill=factor(Attrition)))+ geom_boxplot(width=0.6),
  ggplot(Emp_attrition_data, aes(x=factor(Attrition),y=log(TotalWorkingYears), fill=factor(Attrition)))+ geom_boxplot(width=0.6),
  ggplot(Emp_attrition_data, aes(x=factor(Attrition),y=log(MonthlyIncome), fill=factor(Attrition)))+ geom_boxplot(width=0.6),
  ggplot(Emp_attrition_data, aes(x=factor(Attrition),y=StockOptionLevel, fill=factor(Attrition)))+ geom_boxplot(width=0.6),
  align = "v",nrow = 1
)


# Second set 
plot_grid(
  ggplot(Emp_attrition_data, aes(x=factor(Attrition),y=YearsWithCurrManager, fill=factor(Attrition)))+ geom_boxplot(width=0.6),
  ggplot(Emp_attrition_data, aes(x=factor(Attrition),y=Avg_emp_time_at_office, fill=factor(Attrition)))+ geom_boxplot(width=0.6),
  ggplot(Emp_attrition_data, aes(x=factor(Attrition),y=Emp_Comp_ratio, fill=factor(Attrition)))+ geom_boxplot(width=0.6), 
  ggplot(Emp_attrition_data, aes(x=factor(Attrition),y=TrainingTimesLastYear, fill=factor(Attrition)))+ geom_boxplot(width=0.6),
  align = "v",nrow = 1
)

# Correlation between numeric variables
ggpairs(Emp_attrition_data[, c("Age", "TotalWorkingYears","MonthlyIncome","YearsWithCurrManager","Avg_emp_time_at_office" , "Emp_Comp_ratio","TrainingTimesLastYear","YearsSinceLastPromotion","Avg_emp_time_at_office")])



# ----------------------------------------- End of Data Exploration -------------------------------------------------- #


# Create separate dataset for factors and continuous variables post feature creation

# Identify variables only of type factor 
factor_2_df <- Emp_attrition_data[,which(sapply(Emp_attrition_data, is.factor))]
str(factor_2_df)

# Identify variables only of type numeric/integer
continuous_x_df <- Emp_attrition_data[,which(sapply(Emp_attrition_data, is.numeric))]
str(continuous_x_df) # 4410 obs. of  19 variables

# Exclude variables which are not required as we have transformed version of them
continuous_2_df <- continuous_x_df[c(-4,-5,-6,-7,-11,-12,-15,-19)]
str(continuous_2_df) # 4410 obs. of  11 variables
summary(continuous_2_df)

# check the proportion of event (employee leave org) and non event (employee leave org) in the dependent variable attrition
table(Emp_attrition_data$Attrition)

# Observation: So there is class bias: dataset contains 711 of event and 4410 of non-events, attrition rate is 16%

# ------------------------------------------------ Feature Standardization ---------------------------------------------------#


# Normalising continuous features 

continuous_2_df$Age <- scale(continuous_2_df$Age)
continuous_2_df$StockOptionLevel <- scale(continuous_2_df$StockOptionLevel)
continuous_2_df$TrainingTimesLastYear <- scale(continuous_2_df$TrainingTimesLastYear)
continuous_2_df$YearsWithCurrManager <- scale(continuous_2_df$YearsWithCurrManager)
continuous_2_df$Avg_emp_time_at_office <- scale(continuous_2_df$Avg_emp_time_at_office)
continuous_2_df$Emp_Comp_ratio <- scale(continuous_2_df$Emp_Comp_ratio)
continuous_2_df$MonthlyIncome_transformed <- scale(continuous_2_df$MonthlyIncome_transformed)
continuous_2_df$TotalWorkingYears <- scale(continuous_2_df$TotalWorkingYears)


# --------------------------------- Dummy variable creation --------------------------------------------------------- #


# creating dummy variables for factor attributes
emp_dummies<- data.frame(sapply(factor_2_df, 
                            function(x) data.frame(model.matrix(~x-1,data =factor_2_df))))

dim(emp_dummies) # 4410 obs. of  102 variables

# Final dataset

EmpChurn_final<- cbind(continuous_2_df,emp_dummies) 
dim(EmpChurn_final) # 4410 obs. of  113 variables


# ----------------------------------- Split data set into train and test ------------------------------------------------ #

# Since event is just 16% compared to non event we will create train dataset with equal proportion of event and non event
# ------ Create train 

# For training dataset, select event and non-event in equal proportion 
Attrition_Yes <- EmpChurn_final[which(EmpChurn_final$Attrition == 1),]   # all yes
Attrition_No <- EmpChurn_final[which(EmpChurn_final$Attrition == 0),]   # all no

set.seed(1000)
Attrition_Yes_train <-sample(1:nrow(Attrition_Yes), 0.7*nrow(Attrition_Yes))  # "yes" rows for training dataset
Attrition_No_train <- sample(1:nrow(Attrition_No), 0.7*nrow(Attrition_Yes))   # "no" rows for training dataset; as many "no" as "yes"

training_yes <- Attrition_Yes[Attrition_Yes_train, ]  
training_no <- Attrition_No[Attrition_No_train, ]
trainingData <- rbind(training_yes, training_no)  # row bind the "Yes" and "No" 

table(trainingData$Attrition) # equal proportion of events and non-events
str(trainingData) # 994 obs. of  113 variables

# create Test datasets
test_yes <- Attrition_Yes[-Attrition_Yes_train, ]
test_no <- Attrition_No[-Attrition_No_train, ]
testData <- rbind(test_yes, test_no)  # row bind the "Yes" and "No"

table(testData$Attrition) 


# --------------------------------------- Model Building -------------------------------------------

# ------ Logistic Regression

#Initial model
model_i1 = glm(Attrition ~ ., data = trainingData, family = "binomial")
summary_glm_i1 <- summary(model_i1)  # AIC: 1059.4...nullDev 1377.98 ...resDev 943.44

vif(model_i1)

# on executing vif(model_i1) I got Error in vif.default(model_1) : there are aliased coefficients in the model
# reason: there are variables which are prefectly multicollinear

# Solution: Execute below code to identify the alias

# Identify linearly dependent variables and exclude these variables

# Use ''alias'' to identify variables that are linearly dependent on others (i.e. cause perfect multicollinearity)
alias( glm(Attrition ~ ., data = trainingData, family = "binomial"))

# the linearly dependent variables
attributes(alias(model_i1)$Complete)$dimnames[[1]]

# Due to prefectly multicollinear between following variables exclude them
# JobRole.xSales.Representative, Survey_EnvironmentSatisfaction.xNot.Available,Survey_JobSatisfaction.xNot.Available, Survey_WorkLifeBalance.xNot.Available ,       
# Survey_JobInvolvement.xVery_High, Survey_PerformanceRating.xLow, Survey_PerformanceRating.xGood, Survey_PerformanceRating.xOutstanding,   
# BusinessTravel.xTravel_Rarely, Department.xSales ,Education.xDoctor,  EducationField.xTechnical.Degree,Gender.xMale, JobLevel.x5,                                  
# MaritalStatus.xSingle, PercentSalaryHike_bucket.x17.1.19 ,PercentSalaryHike_bucket.x23.1.25, YearsAtCompany_bucket.x8.1.12, 
# DistanceFromHome_bucket.x9.1.12, NumCompaniesWorked_bucket.x8.1.9, YearsSinceLastPromotion_bucket.x8.1.10   

# Re-run the intial model_1

model_i1_1 <- glm( Attrition ~ EmployeeID + Age + StockOptionLevel + TotalWorkingYears + 
                     TrainingTimesLastYear + YearsWithCurrManager + Avg_emp_time_at_office + 
                     Sal_diff + Emp_Comp_ratio + MonthlyIncome_transformed + JobRole.xHealthcare.Representative + 
                     JobRole.xHuman.Resources + JobRole.xLaboratory.Technician + 
                     JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                     JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                     # JobRole.xSales.Representative + 
                     Survey_EnvironmentSatisfaction.xLow + 
                     Survey_EnvironmentSatisfaction.xMedium + Survey_EnvironmentSatisfaction.xHigh + 
                     Survey_EnvironmentSatisfaction.xVery_High + # Survey_EnvironmentSatisfaction.xNot.Available + 
                     Survey_JobSatisfaction.xLow + Survey_JobSatisfaction.xMedium + 
                     Survey_JobSatisfaction.xHigh + Survey_JobSatisfaction.xVery_High + 
                     # Survey_JobSatisfaction.xNot.Available +
                     Survey_WorkLifeBalance.xBad + 
                     Survey_WorkLifeBalance.xGood + Survey_WorkLifeBalance.xBetter + 
                     Survey_WorkLifeBalance.xBest + # Survey_WorkLifeBalance.xNot.Available + 
                     Survey_JobInvolvement.xLow + Survey_JobInvolvement.xMedium + 
                     Survey_JobInvolvement.xHigh + # Survey_JobInvolvement.xVery_High + 
                     # Survey_PerformanceRating.xLow + 
                     # Survey_PerformanceRating.xGood + 
                     Survey_PerformanceRating.xExcellent + # Survey_PerformanceRating.xOutstanding + 
                     BusinessTravel.xNon.Travel + BusinessTravel.xTravel_Frequently + 
                     # BusinessTravel.xTravel_Rarely + 
                     Department.xHuman.Resources + 
                     Department.xResearch...Development + # Department.xSales + 
                     Education.xBelow_College + Education.xCollege + Education.xBachelor + 
                     Education.xMaster + # Education.xDoctor + 
                     EducationField.xHuman.Resources + 
                     EducationField.xLife.Sciences + EducationField.xMarketing + 
                     EducationField.xMedical + EducationField.xOther + # EducationField.xTechnical.Degree + 
                     Gender.xFemale + # Gender.xMale + 
                     JobLevel.x1 + JobLevel.x2 + 
                     JobLevel.x3 + JobLevel.x4 + # JobLevel.x5 + 
                     MaritalStatus.xDivorced + 
                     MaritalStatus.xMarried + # MaritalStatus.xSingle + 
                     PercentSalaryHike_bucket.x11.13 + 
                     PercentSalaryHike_bucket.x13.1.15 + PercentSalaryHike_bucket.x15.1.17 + 
                     # PercentSalaryHike_bucket.x17.1.19 + 
                     PercentSalaryHike_bucket.x19.1.21 + 
                     PercentSalaryHike_bucket.x19.1.23 + # PercentSalaryHike_bucket.x23.1.25 + 
                     YearsAtCompany_bucket.x0.4 + YearsAtCompany_bucket.x12.1.16 + 
                     YearsAtCompany_bucket.x16.1.20 + YearsAtCompany_bucket.x20.1.24 + 
                     YearsAtCompany_bucket.x24.1.28 + YearsAtCompany_bucket.x28.1.32 + 
                     YearsAtCompany_bucket.x32.1.36 + YearsAtCompany_bucket.x36.1.40 + 
                     YearsAtCompany_bucket.x4.1.8 + # YearsAtCompany_bucket.x8.1.12 + 
                     DistanceFromHome_bucket.x0.3 + DistanceFromHome_bucket.x12.1.15 + 
                     DistanceFromHome_bucket.x15.1.18 + DistanceFromHome_bucket.x18.1.21 + 
                     DistanceFromHome_bucket.x21.1.24 + DistanceFromHome_bucket.x24.1.27 + 
                     DistanceFromHome_bucket.x27.1.29 + DistanceFromHome_bucket.x3.1.6 + 
                     DistanceFromHome_bucket.x6.1.9 + # DistanceFromHome_bucket.x9.1.12 + 
                     NumCompaniesWorked_bucket.x0.1 + NumCompaniesWorked_bucket.x1.1.2 + 
                     NumCompaniesWorked_bucket.x2.1.3 + NumCompaniesWorked_bucket.x4.1.5 + 
                     NumCompaniesWorked_bucket.x5.1.6 + NumCompaniesWorked_bucket.x6.1.7 + 
                     NumCompaniesWorked_bucket.x7.1.8 + # NumCompaniesWorked_bucket.x8.1.9 + 
                     YearsSinceLastPromotion_bucket.x0.2 + YearsSinceLastPromotion_bucket.x10.1.12 + 
                     YearsSinceLastPromotion_bucket.x12.1.14 + YearsSinceLastPromotion_bucket.x2.1.4 + 
                     YearsSinceLastPromotion_bucket.x4.1.6, data=trainingData, family= "binomial", control = list(maxit=100))



summary_glm_i1_1 <- summary(model_i1_1)  # AIC: 1020...nullDev 1377.98 ...resDev 840.01

vif(model_i1_1)

# check pseudo R sqr - 0.39
list( summary_glm_i1_1$coefficient, 
      round( 1 - ( summary_glm_i1_1$deviance / summary_glm_i1_1$null.deviance ), 2 ) )



# model 2

# using AIC as the decision criterion and build the second model, which is supposed to be an improvement on the first model
# Stepwise selection

model_i2<- stepAIC(model_i1_1, direction="both")     # AIC=1020.01
summary_glm_i2 <- summary(model_i2)  # AIC: 957.67 ...nullDev 1377.98 ...resDev   861.67 
 

# Identify multicollinearity through VIF check

vif(model_i2)
# except for JobLevel.x1 and JobLevel.x2 other collinearity is within acceptable limits; 
# these two variables can be excluded since they are not significant 

# pseudo R sqr - 0.37
list( summary_glm_i2$coefficient, 
      round( 1 - ( summary_glm_i2$deviance / summary_glm_i2$null.deviance ), 2 ) )


# sort on p value for display
modcoef <- summary(model_i2)[["coefficients"]]
modcoef[order(modcoef[ , 4]), ]         


# model 3

# executing algo after excluding variables those are statistically low in significance

model_i3 <- glm( Attrition ~  
                     Age + TotalWorkingYears + YearsWithCurrManager + 
                     Avg_emp_time_at_office + JobRole.xResearch.Director +
                     Survey_EnvironmentSatisfaction.xHigh + Survey_EnvironmentSatisfaction.xVery_High +
                     Survey_JobSatisfaction.xLow + Survey_JobInvolvement.xLow + Survey_JobInvolvement.xMedium + 
                     Survey_JobInvolvement.xHigh + BusinessTravel.xTravel_Frequently + 
                     Department.xHuman.Resources + MaritalStatus.xDivorced + 
                     MaritalStatus.xMarried + PercentSalaryHike_bucket.x11.13 + 
                     PercentSalaryHike_bucket.x13.1.15 + PercentSalaryHike_bucket.x19.1.23 + 
                     YearsAtCompany_bucket.x0.4 + YearsAtCompany_bucket.x12.1.16 + 
                     YearsAtCompany_bucket.x28.1.32 + YearsAtCompany_bucket.x32.1.36 +
                     YearsAtCompany_bucket.x36.1.40 + YearsAtCompany_bucket.x4.1.8 +
                     NumCompaniesWorked_bucket.x0.1 + NumCompaniesWorked_bucket.x2.1.3 +
                     YearsSinceLastPromotion_bucket.x0.2 + YearsSinceLastPromotion_bucket.x4.1.6
                   , data=trainingData, family= "binomial", control = list(maxit=100))

summary_glm_i3 <- summary(model_i3)  # AIC: 1064...nullDev 1377.98 ...resDev  1006

vif(model_i3) # VIF are within acceptable limits

# pseudo R sqr - .27
list( summary_glm_i3$coefficient, 
      round( 1 - ( summary_glm_i3$deviance / summary_glm_i3$null.deviance ), 2 ) )

 

# model 4

# excluding variables those are statistically low significance

model_i4 <- glm( Attrition ~ Age + TotalWorkingYears + Avg_emp_time_at_office + 
                   Survey_EnvironmentSatisfaction.xHigh + Survey_EnvironmentSatisfaction.xVery_High +
                   Survey_JobInvolvement.xHigh + BusinessTravel.xTravel_Frequently + 
                   Department.xHuman.Resources + MaritalStatus.xDivorced + 
                   MaritalStatus.xMarried + YearsAtCompany_bucket.x28.1.32 +
                   YearsAtCompany_bucket.x32.1.36 + YearsAtCompany_bucket.x36.1.40 +
                   NumCompaniesWorked_bucket.x0.1 + NumCompaniesWorked_bucket.x2.1.3 +
                   YearsSinceLastPromotion_bucket.x0.2 
                 , data=trainingData, family= "binomial")

summary_glm_i4 <- summary(model_i4)  # AIC: 1107.1 ...nullDev 1377.98 ...resDev  1073.1 

vif(model_i4) # VIF are within acceptable limits

# pseudo R sqr - .22
list( summary_glm_i4$coefficient, 
      round( 1 - ( summary_glm_i4$deviance / summary_glm_i4$null.deviance ), 2 ) )


# model 5

# excluding variables those are statistically low significance

model_i5 <- glm( Attrition ~ Age + TotalWorkingYears + 
                   Avg_emp_time_at_office + 
                   Survey_EnvironmentSatisfaction.xHigh + 
                   Survey_EnvironmentSatisfaction.xVery_High +
                   BusinessTravel.xTravel_Frequently + 
                   Department.xHuman.Resources + 
                   MaritalStatus.xDivorced + 
                   MaritalStatus.xMarried + 
                   YearsAtCompany_bucket.x28.1.32 +
                   YearsAtCompany_bucket.x32.1.36 +
                   YearsAtCompany_bucket.x36.1.40 +
                   NumCompaniesWorked_bucket.x0.1 +
                   NumCompaniesWorked_bucket.x2.1.3 
                 , data=trainingData, family= "binomial")

summary_glm_i5 <- summary(model_i5)  # AIC: 1107.5 ...nullDev 1377.98 ...resDev  1077.5

vif(model_i5) # VIF are within acceptable limits

# pseudo R sqr - .22
list( summary_glm_i5$coefficient, 
      round( 1 - ( summary_glm_i5$deviance / summary_glm_i5$null.deviance ), 2 ) )


# model 6

# excluding variables those are statistically low significance

model_i6 <- glm( Attrition ~ 
                   TotalWorkingYears + 
                   Avg_emp_time_at_office + 
                   Survey_EnvironmentSatisfaction.xHigh + 
                   Survey_EnvironmentSatisfaction.xVery_High +
                   BusinessTravel.xTravel_Frequently + 
                   Department.xHuman.Resources + 
                   MaritalStatus.xDivorced + 
                   MaritalStatus.xMarried + 
                   YearsAtCompany_bucket.x28.1.32 +
                   YearsAtCompany_bucket.x36.1.40 +
                   NumCompaniesWorked_bucket.x0.1 +
                   NumCompaniesWorked_bucket.x2.1.3 
                 , data=trainingData, family= "binomial")

summary_glm_i6 <- summary(model_i6)  # AIC: 1122 ...nullDev 1377.98 ...resDev  1096

vif(model_i6) # VIF are within acceptable limits

# pseudo R sqr - .2
list( summary_glm_i6$coefficient, 
      round( 1 - ( summary_glm_i6$deviance / summary_glm_i6$null.deviance ), 2 ) )



# ------ Final model with 12 significant variables in the model

# Since all the remaining variables in model 6 are statistically significant and 
# multicollinearlity is within acceptable limit we will consider model 6 as final

final_model <- model_i6


# Interpreation: For continuous variables as follows:
# For every one unit increase in TotalWorkingYears, the log odds of quitting the company decreases by 0.72422
# Similarly For every one unit increase in Avg_emp_time_at_office, the log odds of quitting the company increases by 0.61311


# predicted probability
summary(model_i6$fitted.values)

# distribution of predicted probability
hist(model_i6$fitted.values, main = " Histogram ",xlab = "Probability of employee quiting", col = 'light green')


# -------------------------------------- End of Model Creation ------------------------------------------------------

# -------------------------------------- Model Performance Evaluation ------------------------------------------------------

# 1 Confusion Matrix 

# predicted probabilities of Emp Churn on test data

rm(test_pred)
test_pred = predict(final_model, type = "response", newdata = testData[,-3])

summary(test_pred) # We observe that probability varies between 0.01401 and 0.98453

testData$prob <- test_pred    
dim(testData) # 3416 obs. of  114 variables


# Using the probability cutoff of 50%.

test_pred_churn_0.5 <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_churn <- factor(ifelse(testData$Attrition==1,"Yes","No"))

table(test_actual_churn,test_pred_churn_0.5)

#                   test_pred_churn_0.5
# test_actual_churn    No  Yes
#                No  2210  992
#               Yes    60  154

# model's accuracy
# True positives = 2210 + 154 = 2364
# Total = 2210 + 992 + 60 + 154 = 3416
# 2364/3416 = 69%

# At 50% probablity cutoff, accuracy of model is 69%

test_conf_0.5 <- confusionMatrix(test_pred_churn_0.5, test_actual_churn, positive = "Yes")

# Accuracy    : 0.692
# Sensitivity : 0.6902         
# Specificity : 0.7196

# --- # Let's use the probability cutoff of 40%

test_pred_churn_0.4 <- factor(ifelse(test_pred >= 0.40, "Yes", "No"))

table(test_actual_churn,test_pred_churn_0.4)

#                   test_pred_churn_0.4
# test_actual_churn    No  Yes
#                No  1732  1470
#               Yes    38  176

test_conf_0.4 <- confusionMatrix(test_pred_churn_0.4, test_actual_churn, positive = "Yes")

# Accuracy    : 0.5585
# Sensitivity : 0.82243         
# Specificity : 0.54091

# --- # Let's use the probability cutoff of 30%

test_pred_churn_0.3 <- factor(ifelse(test_pred >= 0.30, "Yes", "No"))

table(test_actual_churn,test_pred_churn_0.3)

#                   test_pred_churn_0.4
# test_actual_churn    No  Yes
#                No  1166  2036
#               Yes    18  196

test_conf_0.3 <- confusionMatrix(test_pred_churn_0.3, test_actual_churn, positive = "Yes")

# Accuracy    : 0.3987
# Sensitivity : 0.91589         
# Specificity : 0.36415

# So we observe that as cut-off decreases Specificity is decreasing and Sensitivity is increasing


# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_churn <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_churn, test_actual_churn, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Creating cutoff values from 0.01401 and 0.98453 for plotting and initiallizing a matrix of 100 X 3.

# Summary of test probability

summary(test_pred)   # min = 0.01401 and max = 0.98453

s = seq(.01,.80,length=100)
OUT = matrix(0,100,3)

for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 


plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.01)]   # optimal probability cut-off 0.5127273


# Let's choose a cutoff value of 0.5127273 for final model

test_cutoff_churn <- factor(ifelse(test_pred >=0.51, "Yes", "No"))
conf_final <- confusionMatrix(test_cutoff_churn, test_actual_churn, positive = "Yes")
acc <- conf_final$overall[1]
sens <- conf_final$byClass[1]
spec <- conf_final$byClass[2]

acc # 0.7016979 
sens # 0.7056075 
spec # 0.7014366



# --------------------------- # ROC curve ------------------------------------------------------------ #

roc(Attrition~final_model$fitted.values, data = trainingData, plot = TRUE, main = "ROC CURVE", col= "blue")

auc(Attrition~final_model$fitted.values, data = trainingData)   # Area under the curve: 0.7955

# Observation: Predictive power of model is 79.55 %

# --------------------------- # KS -statistic - Test Data -------------------------------------------- #

test_cutoff_churn <- ifelse(test_cutoff_churn=="Yes",1,0)
test_actual_churn <- ifelse(test_actual_churn=="Yes",1,0)


#on testing  data
pred_object_test<- prediction(test_cutoff_churn, test_actual_churn)
performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test)  # 0.3156614


# --------------------------------------- Lift & Gain Chart ------------------------------------------- #

# plotting the lift chart

# Loading dplyr package 
require(dplyr)
library(dplyr)

lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

Churn_decile = lift(test_actual_churn, test_pred, groups = 10)  

# Obsrvation: 69 % of churns are identified in first three decile
